-- MySQL dump 10.17  Distrib 10.3.22-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: motoroli_inventoryapp
-- ------------------------------------------------------
-- Server version	10.3.22-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemcode` varchar(30) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `groupname` varchar(100) DEFAULT NULL,
  `purchaseprice` float(10,2) DEFAULT 0.00,
  `sellingprice` float(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` (`id`, `itemcode`, `itemname`, `groupname`, `purchaseprice`, `sellingprice`) VALUES (1,NULL,'Celana Tali (50/80)','',0.00,0.00),(2,NULL,'Celana Tali (40/50)',NULL,0.00,0.00),(3,NULL,'Celana Ketat Besar (40)',NULL,0.00,0.00),(4,NULL,'Celana Dugem 3/4 (50/60)',NULL,0.00,0.00),(5,NULL,'Celana Dugem 7/8 (60/70)',NULL,0.00,0.00),(6,NULL,'Celana Kulot 3/4 (50/60)',NULL,0.00,0.00),(7,NULL,'Celana Kulot 7/8 (70/80)','',0.00,0.00),(8,NULL,'Celana Kulot Panjang (100)',NULL,0.00,0.00),(9,NULL,'Celana Kulot Biasa 7/8 (50)',NULL,0.00,0.00),(10,NULL,'Celana Joger Kecil (50)',NULL,0.00,0.00),(11,NULL,'Celana Printing Ban Karet Biasa (100)','',0.00,0.00),(12,NULL,'Celana Printing Ban Alus (150)',NULL,0.00,0.00),(13,NULL,'Celana Printing Ban Karet Alus (150)',NULL,0.00,0.00),(14,NULL,'Celana Printing Anak Karet (70/80)',NULL,0.00,0.00),(15,NULL,'Celana Kodok Anak (50/60)',NULL,0.00,0.00),(16,NULL,'Celana Panjang Kain Anak (70/80)',NULL,0.00,0.00),(17,NULL,'Celana Levis Cewek (100)',NULL,0.00,0.00),(18,NULL,'Celana levis Pendek Cowok (150)',NULL,0.00,0.00),(19,NULL,'Celana Levis Anak (100)',NULL,0.00,0.00),(20,NULL,'Celana Levis Panjang Laki2 (250)',NULL,0.00,0.00),(21,NULL,'Celana Panjang Alus Laki2 (200)',NULL,0.00,0.00),(22,NULL,'Celana Trimming Panjang (80/100)',NULL,0.00,0.00),(23,NULL,'Celana Trimming Ban Putih (70/80)',NULL,0.00,0.00),(24,NULL,'Celana Levis Panjang Cewek (150)',NULL,0.00,0.00),(25,NULL,'Kaos Anak Kecil (50)',NULL,0.00,0.00),(26,NULL,'Kaos 7/8 Anak (60/0)',NULL,0.00,0.00),(27,NULL,'Kaos Tanggung (S/M) (50)',NULL,0.00,0.00),(28,NULL,'Kaos L (60/70)',NULL,0.00,0.00),(29,NULL,'Kaos XL, XXL (80/90)',NULL,0.00,0.00),(30,NULL,'Kaos Krah (70/80)',NULL,0.00,0.00),(31,NULL,'Kaos Panjang (Sweater) (100)',NULL,0.00,0.00),(32,NULL,'Kaos Cewek (50/70)',NULL,0.00,0.00),(33,NULL,'Hem/Kemeja Dewasa',NULL,0.00,0.00),(34,NULL,'Hem/Kemeja Anak',NULL,0.00,0.00),(35,NULL,'Pasangan Anak (50)',NULL,0.00,0.00),(36,NULL,'Pasangan Anak (60/70)',NULL,0.00,0.00),(37,NULL,'Pasangan Anak (70/80)',NULL,0.00,0.00),(38,NULL,'Pasangan Anak Panjang Besar (100)',NULL,0.00,0.00),(39,NULL,'Pasangan Dewasa (100)',NULL,0.00,0.00),(40,NULL,'Blus Anak Biasa (50)',NULL,0.00,0.00),(41,NULL,'Blus Anak (100)',NULL,0.00,0.00),(42,NULL,'Rok Anak (50/60)',NULL,0.00,0.00),(43,NULL,'Rok Dewasa Hitam (100)',NULL,0.00,0.00),(44,NULL,'Rok Panjang Dewasa (100)',NULL,0.00,0.00),(45,NULL,'Blus Dewasa / mama (100)',NULL,0.00,0.00),(46,NULL,'Blus Dewasa Biasa (80)',NULL,0.00,0.00),(47,NULL,'Blus Terusan Dewasa (150)',NULL,0.00,0.00),(48,NULL,'Sweater Anak Kecil (80/100)',NULL,0.00,0.00),(49,NULL,'Sweater Dewasa Cewek (80/100)',NULL,0.00,0.00),(50,NULL,'Jaket Anak Kecil (70/80)',NULL,0.00,0.00),(51,NULL,'Jaket Anak Kain/Parasit (100/120)',NULL,0.00,0.00),(52,NULL,'Jaket Kain Dewasa (140/150)',NULL,0.00,0.00),(53,NULL,'Jaket Parasit D (150/200)',NULL,0.00,0.00),(54,NULL,'Jaket Parasit Dewasa Topi (200/250)',NULL,0.00,0.00),(55,NULL,'Tudung Lubang Maling (30)',NULL,0.00,0.00),(56,NULL,'Tudung Tebal Biasa (30/40)',NULL,0.00,0.00),(57,NULL,'Tudung Loreng skoter) (30/40)',NULL,0.00,0.00),(58,NULL,'Tudung Alus (30/40)',NULL,0.00,0.00),(59,NULL,'Tudung Bromo (50)',NULL,0.00,0.00),(60,NULL,'Masker Buf (30/40)',NULL,0.00,0.00),(61,NULL,'Masker Biasa',NULL,0.00,0.00),(62,NULL,'Topi Anak',NULL,0.00,0.00),(63,NULL,'Topi Dewasa',NULL,0.00,0.00),(64,NULL,'Topi SD',NULL,0.00,0.00),(65,NULL,'Topi SMP',NULL,0.00,0.00),(66,NULL,'Topi SMA',NULL,0.00,0.00),(67,NULL,'Kaos Dalam Cowok Dewasa',NULL,0.00,0.00),(68,NULL,'Kaos Dalam Cewek',NULL,0.00,0.00),(69,NULL,'Ikat Pinggang Rasta (50)',NULL,0.00,0.00),(70,NULL,'Ikat Pinggang Biasa (40)',NULL,0.00,0.00),(71,NULL,'Ikat Pinggang Kulit (70/80)',NULL,0.00,0.00),(72,NULL,'Ikat Pinggang Kecil (30/40)',NULL,0.00,0.00),(73,NULL,'CD Cewek Dewasa',NULL,0.00,0.00),(74,NULL,'Tas Pinggang',NULL,0.00,0.00),(75,NULL,'Tas Gendong',NULL,0.00,0.00),(76,NULL,'CD Cowok Alus',NULL,0.00,0.00),(77,NULL,'CD Cowok Biasa',NULL,0.00,0.00),(78,NULL,'Sandal',NULL,0.00,0.00),(79,NULL,'Kaos Tangan',NULL,0.00,0.00),(80,NULL,'KK Dewasa',NULL,0.00,0.00),(81,NULL,'KK Anak',NULL,0.00,0.00),(82,NULL,'Sepatu Ket',NULL,0.00,0.00),(83,NULL,'Sepatu Kulit',NULL,0.00,0.00),(84,NULL,'Sepato Cewek/Vantofel',NULL,0.00,0.00),(85,NULL,'KK Doreng',NULL,0.00,0.00),(86,NULL,'KK Bola',NULL,0.00,0.00);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `item_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `qty` float DEFAULT NULL,
  UNIQUE KEY `uq_stock` (`item_id`,`warehouse_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` (`item_id`, `warehouse_id`, `qty`) VALUES (1,0,0),(1,1,0),(1,2,64),(1,3,86),(2,0,-1),(2,1,0),(2,2,9),(2,3,24),(3,1,0),(3,2,2),(3,3,5),(4,1,0),(4,2,7),(4,3,5),(5,1,0),(5,2,3),(5,3,3),(6,1,0),(6,2,4),(6,3,8),(7,1,0),(7,2,21),(7,3,31),(8,1,0),(8,2,4),(8,3,3),(9,1,0),(9,2,7),(9,3,4),(10,0,-1),(10,1,0),(10,2,5),(10,3,1),(11,1,0),(11,2,18),(11,3,26),(12,0,-2),(12,1,0),(12,2,11),(12,3,3),(13,1,0),(13,2,6),(13,3,8),(14,1,0),(14,2,4),(14,3,2),(15,1,0),(15,2,4),(15,3,1),(16,1,0),(16,2,0),(16,3,3),(17,1,0),(17,2,5),(17,3,5),(18,1,0),(18,2,1),(18,3,0),(19,1,0),(19,2,5),(19,3,0),(20,1,0),(20,2,4),(20,3,3),(21,1,0),(21,2,1),(21,3,1),(22,1,0),(22,2,8),(22,3,9),(23,1,0),(23,2,5),(23,3,9),(24,1,0),(24,2,0),(24,3,1),(25,1,0),(25,2,13),(25,3,3),(26,1,0),(26,2,7),(26,3,1),(27,1,0),(27,2,9),(27,3,3),(28,1,0),(28,2,23),(28,3,20),(29,1,0),(29,2,12),(29,3,7),(30,1,0),(30,2,9),(30,3,3),(31,1,0),(31,2,4),(31,3,8),(32,1,0),(32,2,10),(32,3,6),(33,1,0),(33,2,14),(33,3,5),(34,1,0),(34,2,3),(34,3,0),(35,0,0),(35,1,0),(35,2,26),(35,3,18),(36,1,0),(36,2,21),(36,3,19),(37,1,0),(37,2,35),(37,3,14),(38,1,0),(38,2,5),(38,3,0),(39,1,0),(39,2,1),(39,3,1),(40,1,0),(40,2,5),(40,3,3),(41,1,0),(41,2,7),(41,3,1),(42,1,0),(42,2,3),(42,3,2),(43,1,0),(43,2,6),(43,3,3),(44,1,0),(44,2,4),(44,3,1),(45,1,0),(45,2,17),(45,3,2),(46,1,0),(46,2,18),(46,3,8),(47,1,0),(47,2,8),(47,3,1),(48,1,0),(48,2,1),(48,3,0),(49,1,0),(49,2,2),(49,3,1),(50,1,0),(50,2,6),(50,3,0),(51,1,0),(51,2,10),(51,3,12),(52,1,0),(52,2,2),(52,3,9),(53,1,0),(53,2,2),(53,3,1),(54,1,0),(54,2,10),(54,3,4),(55,1,60),(55,2,5),(55,3,5),(56,1,2),(56,2,6),(56,3,5),(57,1,0),(57,2,1),(57,3,6),(58,1,0),(58,2,1),(58,3,3),(59,1,0),(59,2,3),(59,3,1),(60,1,6),(60,2,-7),(60,3,15),(61,1,0),(61,2,6),(61,3,4),(62,1,3),(62,2,2),(62,3,13),(63,1,22),(63,2,22),(63,3,18),(64,1,20),(64,2,4),(64,3,1),(65,1,10),(65,2,2),(65,3,2),(66,1,0),(66,2,2),(66,3,4),(67,1,0),(67,2,2),(67,3,12),(68,1,7),(68,2,2),(68,3,4),(69,1,7),(69,2,3),(69,3,7),(70,1,0),(70,2,2),(70,3,4),(71,1,0),(71,2,2),(71,3,2),(72,1,0),(72,2,10),(72,3,0),(73,1,36),(73,2,34),(73,3,35),(74,1,0),(74,2,9),(74,3,11),(75,1,0),(75,2,9),(75,3,3),(76,1,0),(76,2,45),(76,3,13),(77,1,0),(77,2,17),(77,3,12),(78,1,0),(78,2,74),(78,3,76),(79,1,0),(79,2,9),(79,3,5),(80,1,120),(80,2,56),(80,3,72),(81,1,0),(81,2,10),(81,3,23),(82,1,0),(82,2,282),(82,3,82),(83,1,0),(83,2,59),(83,3,27),(84,1,0),(84,2,24),(84,3,12),(85,1,2),(85,2,1),(85,3,1),(86,1,0),(86,2,12),(86,3,8);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transdetail`
--

DROP TABLE IF EXISTS `transdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `header_id` int(30) NOT NULL,
  `header_flag` int(255) DEFAULT NULL,
  `transdate` date DEFAULT NULL,
  `item_id` int(255) NOT NULL,
  `qty` float(100,0) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `purchaseprice` float(10,2) DEFAULT NULL,
  `sellingprice` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transdetail`
--

LOCK TABLES `transdetail` WRITE;
/*!40000 ALTER TABLE `transdetail` DISABLE KEYS */;
INSERT INTO `transdetail` (`id`, `header_id`, `header_flag`, `transdate`, `item_id`, `qty`, `warehouse_id`, `purchaseprice`, `sellingprice`) VALUES (1,0,1,'2020-04-20',1,0,1,NULL,NULL),(2,0,1,'2020-04-20',2,0,1,NULL,NULL),(3,0,1,'2020-04-20',3,0,1,NULL,NULL),(4,0,1,'2020-04-20',4,0,1,NULL,NULL),(5,0,1,'2020-04-20',5,0,1,NULL,NULL),(6,0,1,'2020-04-20',6,0,1,NULL,NULL),(7,0,1,'2020-04-20',7,0,1,NULL,NULL),(8,0,1,'2020-04-20',8,0,1,NULL,NULL),(9,0,1,'2020-04-20',9,0,1,NULL,NULL),(10,0,1,'2020-04-20',10,0,1,NULL,NULL),(11,0,1,'2020-04-20',11,0,1,NULL,NULL),(12,0,1,'2020-04-20',12,0,1,NULL,NULL),(13,0,1,'2020-04-20',13,0,1,NULL,NULL),(14,0,1,'2020-04-20',14,0,1,NULL,NULL),(15,0,1,'2020-04-20',15,0,1,NULL,NULL),(16,0,1,'2020-04-20',16,0,1,NULL,NULL),(17,0,1,'2020-04-20',17,0,1,NULL,NULL),(18,0,1,'2020-04-20',18,0,1,NULL,NULL),(19,0,1,'2020-04-20',19,0,1,NULL,NULL),(20,0,1,'2020-04-20',20,0,1,NULL,NULL),(21,0,1,'2020-04-20',21,0,1,NULL,NULL),(22,0,1,'2020-04-20',22,0,1,NULL,NULL),(23,0,1,'2020-04-20',23,0,1,NULL,NULL),(24,0,1,'2020-04-20',24,0,1,NULL,NULL),(25,0,1,'2020-04-20',25,0,1,NULL,NULL),(26,0,1,'2020-04-20',26,0,1,NULL,NULL),(27,0,1,'2020-04-20',27,0,1,NULL,NULL),(28,0,1,'2020-04-20',28,0,1,NULL,NULL),(29,0,1,'2020-04-20',29,0,1,NULL,NULL),(30,0,1,'2020-04-20',30,0,1,NULL,NULL),(31,0,1,'2020-04-20',31,0,1,NULL,NULL),(32,0,1,'2020-04-20',32,0,1,NULL,NULL),(33,0,1,'2020-04-20',33,0,1,NULL,NULL),(34,0,1,'2020-04-20',34,0,1,NULL,NULL),(35,0,1,'2020-04-20',35,0,1,NULL,NULL),(36,0,1,'2020-04-20',36,0,1,NULL,NULL),(37,0,1,'2020-04-20',37,0,1,NULL,NULL),(38,0,1,'2020-04-20',38,0,1,NULL,NULL),(39,0,1,'2020-04-20',39,0,1,NULL,NULL),(40,0,1,'2020-04-20',40,0,1,NULL,NULL),(41,0,1,'2020-04-20',41,0,1,NULL,NULL),(42,0,1,'2020-04-20',42,0,1,NULL,NULL),(43,0,1,'2020-04-20',43,0,1,NULL,NULL),(44,0,1,'2020-04-20',44,0,1,NULL,NULL),(45,0,1,'2020-04-20',45,0,1,NULL,NULL),(46,0,1,'2020-04-20',46,0,1,NULL,NULL),(47,0,1,'2020-04-20',47,0,1,NULL,NULL),(48,0,1,'2020-04-20',48,0,1,NULL,NULL),(49,0,1,'2020-04-20',49,0,1,NULL,NULL),(50,0,1,'2020-04-20',50,0,1,NULL,NULL),(51,0,1,'2020-04-20',51,0,1,NULL,NULL),(52,0,1,'2020-04-20',52,0,1,NULL,NULL),(53,0,1,'2020-04-20',53,0,1,NULL,NULL),(54,0,1,'2020-04-20',54,0,1,NULL,NULL),(55,0,1,'2020-04-20',1,66,2,NULL,NULL),(56,0,1,'2020-04-20',2,10,2,NULL,NULL),(57,0,1,'2020-04-20',3,2,2,NULL,NULL),(58,0,1,'2020-04-20',4,7,2,NULL,NULL),(59,0,1,'2020-04-20',5,3,2,NULL,NULL),(60,0,1,'2020-04-20',6,4,2,NULL,NULL),(61,0,1,'2020-04-20',7,21,2,NULL,NULL),(62,0,1,'2020-04-20',8,4,2,NULL,NULL),(63,0,1,'2020-04-20',9,7,2,NULL,NULL),(64,0,1,'2020-04-20',10,5,2,NULL,NULL),(65,0,1,'2020-04-20',11,20,2,NULL,NULL),(66,0,1,'2020-04-20',12,11,2,NULL,NULL),(67,0,1,'2020-04-20',13,6,2,NULL,NULL),(68,0,1,'2020-04-20',14,4,2,NULL,NULL),(69,0,1,'2020-04-20',15,4,2,NULL,NULL),(70,0,1,'2020-04-20',16,0,2,NULL,NULL),(71,0,1,'2020-04-20',17,5,2,NULL,NULL),(72,0,1,'2020-04-20',18,1,2,NULL,NULL),(73,0,1,'2020-04-20',19,5,2,NULL,NULL),(74,0,1,'2020-04-20',20,4,2,NULL,NULL),(75,0,1,'2020-04-20',21,1,2,NULL,NULL),(76,0,1,'2020-04-20',22,8,2,NULL,NULL),(77,0,1,'2020-04-20',23,5,2,NULL,NULL),(78,0,1,'2020-04-20',24,0,2,NULL,NULL),(79,0,1,'2020-04-20',25,13,2,NULL,NULL),(80,0,1,'2020-04-20',26,7,2,NULL,NULL),(81,0,1,'2020-04-20',27,9,2,NULL,NULL),(82,0,1,'2020-04-20',28,23,2,NULL,NULL),(83,0,1,'2020-04-20',29,14,2,NULL,NULL),(84,0,1,'2020-04-20',30,9,2,NULL,NULL),(85,0,1,'2020-04-20',31,4,2,NULL,NULL),(86,0,1,'2020-04-20',32,10,2,NULL,NULL),(87,0,1,'2020-04-20',33,14,2,NULL,NULL),(88,0,1,'2020-04-20',34,3,2,NULL,NULL),(89,0,1,'2020-04-20',35,27,2,NULL,NULL),(90,0,1,'2020-04-20',36,21,2,NULL,NULL),(91,0,1,'2020-04-20',37,35,2,NULL,NULL),(92,0,1,'2020-04-20',38,5,2,NULL,NULL),(93,0,1,'2020-04-20',39,1,2,NULL,NULL),(94,0,1,'2020-04-20',40,5,2,NULL,NULL),(95,0,1,'2020-04-20',41,7,2,NULL,NULL),(96,0,1,'2020-04-20',42,3,2,NULL,NULL),(97,0,1,'2020-04-20',43,6,2,NULL,NULL),(98,0,1,'2020-04-20',44,4,2,NULL,NULL),(99,0,1,'2020-04-20',45,17,2,NULL,NULL),(100,0,1,'2020-04-20',46,18,2,NULL,NULL),(101,0,1,'2020-04-20',47,8,2,NULL,NULL),(102,0,1,'2020-04-20',48,1,2,NULL,NULL),(103,0,1,'2020-04-20',49,2,2,NULL,NULL),(104,0,1,'2020-04-20',50,6,2,NULL,NULL),(105,0,1,'2020-04-20',51,10,2,NULL,NULL),(106,0,1,'2020-04-20',52,2,2,NULL,NULL),(107,0,1,'2020-04-20',53,2,2,NULL,NULL),(108,0,1,'2020-04-20',54,10,2,NULL,NULL),(109,0,1,'2020-04-20',1,89,3,NULL,NULL),(110,0,1,'2020-04-20',2,24,3,NULL,NULL),(111,0,1,'2020-04-20',3,5,3,NULL,NULL),(112,0,1,'2020-04-20',4,5,3,NULL,NULL),(113,0,1,'2020-04-20',5,3,3,NULL,NULL),(114,0,1,'2020-04-20',6,10,3,NULL,NULL),(115,0,1,'2020-04-20',7,33,3,NULL,NULL),(116,0,1,'2020-04-20',8,3,3,NULL,NULL),(117,0,1,'2020-04-20',9,4,3,NULL,NULL),(118,0,1,'2020-04-20',10,1,3,NULL,NULL),(119,0,1,'2020-04-20',11,28,3,NULL,NULL),(120,0,1,'2020-04-20',12,3,3,NULL,NULL),(121,0,1,'2020-04-20',13,9,3,NULL,NULL),(122,0,1,'2020-04-20',14,3,3,NULL,NULL),(123,0,1,'2020-04-20',15,1,3,NULL,NULL),(124,0,1,'2020-04-20',16,3,3,NULL,NULL),(125,0,1,'2020-04-20',17,5,3,NULL,NULL),(126,0,1,'2020-04-20',18,0,3,NULL,NULL),(127,0,1,'2020-04-20',19,0,3,NULL,NULL),(128,0,1,'2020-04-20',20,3,3,NULL,NULL),(129,0,1,'2020-04-20',21,1,3,NULL,NULL),(130,0,1,'2020-04-20',22,10,3,NULL,NULL),(131,0,1,'2020-04-20',23,9,3,NULL,NULL),(132,0,1,'2020-04-20',24,1,3,NULL,NULL),(133,0,1,'2020-04-20',25,3,3,NULL,NULL),(134,0,1,'2020-04-20',26,1,3,NULL,NULL),(135,0,1,'2020-04-20',27,3,3,NULL,NULL),(136,0,1,'2020-04-20',28,20,3,NULL,NULL),(137,0,1,'2020-04-20',29,7,3,NULL,NULL),(138,0,1,'2020-04-20',30,3,3,NULL,NULL),(139,0,1,'2020-04-20',31,8,3,NULL,NULL),(140,0,1,'2020-04-20',32,6,3,NULL,NULL),(141,0,1,'2020-04-20',33,5,3,NULL,NULL),(142,0,1,'2020-04-20',34,0,3,NULL,NULL),(143,0,1,'2020-04-20',35,18,3,NULL,NULL),(144,0,1,'2020-04-20',36,20,3,NULL,NULL),(145,0,1,'2020-04-20',37,15,3,NULL,NULL),(146,0,1,'2020-04-20',38,0,3,NULL,NULL),(147,0,1,'2020-04-20',39,1,3,NULL,NULL),(148,0,1,'2020-04-20',40,3,3,NULL,NULL),(149,0,1,'2020-04-20',41,1,3,NULL,NULL),(150,0,1,'2020-04-20',42,2,3,NULL,NULL),(151,0,1,'2020-04-20',43,3,3,NULL,NULL),(152,0,1,'2020-04-20',44,1,3,NULL,NULL),(153,0,1,'2020-04-20',45,2,3,NULL,NULL),(154,0,1,'2020-04-20',46,8,3,NULL,NULL),(155,0,1,'2020-04-20',47,1,3,NULL,NULL),(156,0,1,'2020-04-20',48,0,3,NULL,NULL),(157,0,1,'2020-04-20',49,1,3,NULL,NULL),(158,0,1,'2020-04-20',50,0,3,NULL,NULL),(159,0,1,'2020-04-20',51,12,3,NULL,NULL),(160,0,1,'2020-04-20',52,9,3,NULL,NULL),(161,0,1,'2020-04-20',53,1,3,NULL,NULL),(162,0,1,'2020-04-20',54,5,3,NULL,NULL),(164,5,2,'2020-04-21',11,-2,3,0.00,0.00),(165,5,2,'2020-04-21',13,-1,3,0.00,0.00),(166,5,2,'2020-04-21',14,-1,3,0.00,0.00),(180,8,2,'2020-04-21',1,-2,2,0.00,0.00),(181,8,2,'2020-04-21',35,-1,2,0.00,0.00),(186,18,2,'2020-04-22',6,-1,3,0.00,0.00),(187,18,2,'2020-04-22',22,-1,3,0.00,0.00),(188,18,2,'2020-04-22',36,-1,3,0.00,0.00),(189,18,2,'2020-04-22',54,-1,3,0.00,0.00),(191,58,2,'2020-04-22',2,-1,2,0.00,0.00),(192,58,2,'2020-04-22',29,-1,2,0.00,0.00),(193,59,2,'2020-04-22',6,-1,3,0.00,0.00),(194,76,2,'2020-04-22',2,-1,0,0.00,0.00),(195,76,2,'2020-04-22',10,-1,0,0.00,0.00),(196,76,2,'2020-04-22',12,-2,0,0.00,0.00),(197,88,2,'2020-04-23',1,-2,3,0.00,0.00),(198,88,2,'2020-04-23',7,-1,3,0.00,0.00),(199,133,2,'2020-04-23',11,-1,2,0.00,0.00),(200,134,2,'2020-04-23',1,-1,3,0.00,0.00),(201,134,2,'2020-04-23',7,-1,3,0.00,0.00),(202,156,2,'2020-04-24',37,-1,3,0.00,0.00),(203,170,2,'2020-04-24',11,-1,2,0.00,0.00),(204,170,2,'2020-04-24',29,-1,2,0.00,0.00),(205,0,1,'2020-04-24',55,60,1,NULL,NULL),(206,0,1,'2020-04-24',56,2,1,NULL,NULL),(207,0,1,'2020-04-24',57,0,1,NULL,NULL),(208,0,1,'2020-04-24',58,0,1,NULL,NULL),(209,0,1,'2020-04-24',59,0,1,NULL,NULL),(210,0,1,'2020-04-24',60,6,1,NULL,NULL),(211,0,1,'2020-04-24',61,0,1,NULL,NULL),(212,0,1,'2020-04-24',62,3,1,NULL,NULL),(213,0,1,'2020-04-24',63,22,1,NULL,NULL),(214,0,1,'2020-04-24',64,20,1,NULL,NULL),(215,0,1,'2020-04-24',65,10,1,NULL,NULL),(216,0,1,'2020-04-24',66,0,1,NULL,NULL),(217,0,1,'2020-04-24',67,0,1,NULL,NULL),(218,0,1,'2020-04-24',68,7,1,NULL,NULL),(219,0,1,'2020-04-24',69,7,1,NULL,NULL),(220,0,1,'2020-04-24',70,0,1,NULL,NULL),(221,0,1,'2020-04-24',71,0,1,NULL,NULL),(222,0,1,'2020-04-24',72,0,1,NULL,NULL),(223,0,1,'2020-04-24',73,36,1,NULL,NULL),(224,0,1,'2020-04-24',74,0,1,NULL,NULL),(225,0,1,'2020-04-24',75,0,1,NULL,NULL),(226,0,1,'2020-04-24',76,0,1,NULL,NULL),(227,0,1,'2020-04-24',77,0,1,NULL,NULL),(228,0,1,'2020-04-24',78,0,1,NULL,NULL),(229,0,1,'2020-04-24',79,0,1,NULL,NULL),(230,0,1,'2020-04-24',80,120,1,NULL,NULL),(231,0,1,'2020-04-24',81,0,1,NULL,NULL),(232,0,1,'2020-04-24',82,0,1,NULL,NULL),(233,0,1,'2020-04-24',83,0,1,NULL,NULL),(234,0,1,'2020-04-24',84,0,1,NULL,NULL),(235,0,1,'2020-04-24',85,2,1,NULL,NULL),(236,0,1,'2020-04-24',86,0,1,NULL,NULL),(237,0,1,'2020-04-24',55,5,2,NULL,NULL),(238,0,1,'2020-04-24',56,6,2,NULL,NULL),(239,0,1,'2020-04-24',57,1,2,NULL,NULL),(240,0,1,'2020-04-24',58,1,2,NULL,NULL),(241,0,1,'2020-04-24',59,3,2,NULL,NULL),(242,0,1,'2020-04-24',60,-7,2,NULL,NULL),(243,0,1,'2020-04-24',61,6,2,NULL,NULL),(244,0,1,'2020-04-24',62,2,2,NULL,NULL),(245,0,1,'2020-04-24',63,22,2,NULL,NULL),(246,0,1,'2020-04-24',64,4,2,NULL,NULL),(247,0,1,'2020-04-24',65,2,2,NULL,NULL),(248,0,1,'2020-04-24',66,2,2,NULL,NULL),(249,0,1,'2020-04-24',67,2,2,NULL,NULL),(250,0,1,'2020-04-24',68,2,2,NULL,NULL),(251,0,1,'2020-04-24',69,3,2,NULL,NULL),(252,0,1,'2020-04-24',70,2,2,NULL,NULL),(253,0,1,'2020-04-24',71,2,2,NULL,NULL),(254,0,1,'2020-04-24',72,10,2,NULL,NULL),(255,0,1,'2020-04-24',73,34,2,NULL,NULL),(256,0,1,'2020-04-24',74,9,2,NULL,NULL),(257,0,1,'2020-04-24',75,9,2,NULL,NULL),(258,0,1,'2020-04-24',76,45,2,NULL,NULL),(259,0,1,'2020-04-24',77,17,2,NULL,NULL),(260,0,1,'2020-04-24',78,74,2,NULL,NULL),(261,0,1,'2020-04-24',79,9,2,NULL,NULL),(262,0,1,'2020-04-24',80,56,2,NULL,NULL),(263,0,1,'2020-04-24',81,10,2,NULL,NULL),(264,0,1,'2020-04-24',82,282,2,NULL,NULL),(265,0,1,'2020-04-24',83,59,2,NULL,NULL),(266,0,1,'2020-04-24',84,24,2,NULL,NULL),(267,0,1,'2020-04-24',85,1,2,NULL,NULL),(268,0,1,'2020-04-24',86,12,2,NULL,NULL),(269,0,1,'2020-04-24',55,5,3,NULL,NULL),(270,0,1,'2020-04-24',56,5,3,NULL,NULL),(271,0,1,'2020-04-24',57,6,3,NULL,NULL),(272,0,1,'2020-04-24',58,3,3,NULL,NULL),(273,0,1,'2020-04-24',59,1,3,NULL,NULL),(274,0,1,'2020-04-24',60,15,3,NULL,NULL),(275,0,1,'2020-04-24',61,4,3,NULL,NULL),(276,0,1,'2020-04-24',62,13,3,NULL,NULL),(277,0,1,'2020-04-24',63,18,3,NULL,NULL),(278,0,1,'2020-04-24',64,1,3,NULL,NULL),(279,0,1,'2020-04-24',65,2,3,NULL,NULL),(280,0,1,'2020-04-24',66,4,3,NULL,NULL),(281,0,1,'2020-04-24',67,12,3,NULL,NULL),(282,0,1,'2020-04-24',68,4,3,NULL,NULL),(283,0,1,'2020-04-24',69,7,3,NULL,NULL),(284,0,1,'2020-04-24',70,4,3,NULL,NULL),(285,0,1,'2020-04-24',71,2,3,NULL,NULL),(286,0,1,'2020-04-24',72,0,3,NULL,NULL),(287,0,1,'2020-04-24',73,35,3,NULL,NULL),(288,0,1,'2020-04-24',74,11,3,NULL,NULL),(289,0,1,'2020-04-24',75,3,3,NULL,NULL),(290,0,1,'2020-04-24',76,13,3,NULL,NULL),(291,0,1,'2020-04-24',77,12,3,NULL,NULL),(292,0,1,'2020-04-24',78,76,3,NULL,NULL),(293,0,1,'2020-04-24',79,5,3,NULL,NULL),(294,0,1,'2020-04-24',80,72,3,NULL,NULL),(295,0,1,'2020-04-24',81,23,3,NULL,NULL),(296,0,1,'2020-04-24',82,82,3,NULL,NULL),(297,0,1,'2020-04-24',83,27,3,NULL,NULL),(298,0,1,'2020-04-24',84,12,3,NULL,NULL),(299,0,1,'2020-04-24',85,1,3,NULL,NULL),(300,0,1,'2020-04-24',86,8,3,NULL,NULL);
/*!40000 ALTER TABLE `transdetail` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`motoroli_admin`@`%`*/ /*!50003 TRIGGER `insert_transdetail` AFTER INSERT ON `transdetail` FOR EACH ROW INSERT INTO stock
	(item_id, warehouse_id, qty)
VALUES
	(new.item_id, new.warehouse_id, new.qty)
ON DUPLICATE KEY UPDATE
	qty     = qty + new.qty
; */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`motoroli_admin`@`%`*/ /*!50003 TRIGGER `update_transdetail` AFTER UPDATE ON `transdetail` FOR EACH ROW INSERT INTO stock
	(item_id, warehouse_id, qty)
VALUES
	(new.item_id, new.warehouse_id, new.qty)
ON DUPLICATE KEY UPDATE
	qty     = qty - old.qty + new.qty
; */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`motoroli_admin`@`%`*/ /*!50003 TRIGGER `delete_transdetail` AFTER DELETE ON `transdetail` FOR EACH ROW INSERT INTO stock
	(item_id, warehouse_id, qty)
VALUES
	(old.item_id, old.warehouse_id, 0)
ON DUPLICATE KEY UPDATE
	qty     = qty - old.qty
; */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `transheader`
--

DROP TABLE IF EXISTS `transheader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transheader` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transno` varchar(30) NOT NULL,
  `header_flag` int(255) DEFAULT NULL,
  `transdate` datetime DEFAULT NULL,
  `warehouse_id` int(255) NOT NULL,
  `dest_warehouse_id` int(11) DEFAULT NULL,
  `notes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uq_transno` (`transno`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transheader`
--

LOCK TABLES `transheader` WRITE;
/*!40000 ALTER TABLE `transheader` DISABLE KEYS */;
INSERT INTO `transheader` (`id`, `transno`, `header_flag`, `transdate`, `warehouse_id`, `dest_warehouse_id`, `notes`) VALUES (5,'HZF2NB85XRCS',2,'2020-04-21 06:19:14',3,0,NULL),(8,'18Y4P4UR77RZ',2,'2020-04-21 06:58:20',2,0,NULL),(9,'ORGR0N3SQP30',1,'2020-04-21 11:07:30',2,0,NULL),(18,'2V7WTUDDVNV4',2,'2020-04-22 07:12:30',3,0,NULL),(58,'69M7KVV640AU',2,'2020-04-22 03:11:24',2,0,NULL),(59,'QLC9VPEYUT5O',2,'2020-04-22 03:15:17',3,0,NULL),(75,'KW2N3TL6L333',3,'2020-04-22 01:44:42',0,0,NULL),(76,'29R3YKGRUXY4',2,'2020-04-22 01:45:25',0,0,NULL),(88,'V8DYB00VQEVO',2,'2020-04-23 04:49:54',3,0,NULL),(133,'J7FX7CH6Q3W1',2,'2020-04-23 04:58:53',2,0,NULL),(134,'HJSPX80HRMJC',2,'2020-04-23 04:59:19',3,0,NULL),(156,'9GBDY8UTFUCG',2,'2020-04-24 02:38:51',3,0,NULL),(170,'GFFYGD1MWKTI',2,'2020-04-24 12:23:38',2,0,NULL);
/*!40000 ALTER TABLE `transheader` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`) VALUES (2,'admin',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_stock`
--

DROP TABLE IF EXISTS `v_stock`;
/*!50001 DROP VIEW IF EXISTS `v_stock`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_stock` (
  `itemname` tinyint NOT NULL,
  `warehousename` tinyint NOT NULL,
  `stock` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `warehouse`
--

DROP TABLE IF EXISTS `warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `warehousename` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouse`
--

LOCK TABLES `warehouse` WRITE;
/*!40000 ALTER TABLE `warehouse` DISABLE KEYS */;
INSERT INTO `warehouse` (`id`, `warehousename`) VALUES (1,'Gudang'),(2,'Kios 1'),(3,'Kios 2');
/*!40000 ALTER TABLE `warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'motoroli_inventoryapp'
--

--
-- Dumping routines for database 'motoroli_inventoryapp'
--

--
-- Final view structure for view `v_stock`
--

/*!50001 DROP TABLE IF EXISTS `v_stock`*/;
/*!50001 DROP VIEW IF EXISTS `v_stock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`motoroli_admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock` AS select `b`.`itemname` AS `itemname`,`c`.`warehousename` AS `warehousename`,`a`.`qty` AS `stock` from ((`stock` `a` join `item` `b` on(`a`.`item_id` = `b`.`id`)) join `warehouse` `c` on(`a`.`warehouse_id` = `c`.`id`)) where `a`.`qty` <> 0 order by `b`.`itemname`,`c`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-24 21:03:53
